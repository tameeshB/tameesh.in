<?PHP ?>
<html>
<head>
	 <title>Gallery | Tameesh Biswas</title>
	 <link rel="stylesheet" type="text/css" media="screen" href="../uniform.css">
	 <link rel="stylesheet" type="text/css" media="screen" href="gallery.css">
	 <meta charset="utf-8">
  	 <meta name="viewport" content="width=device-width, initial-scale=1">

  	 <meta name="viewport" content="width=device-width, initial-scale=1">
  	 <!--<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	 <link href='https://fonts.googleapis.com/css?family=Josefin+Sans:400,400italic|Dancing+Script' rel='stylesheet' type='text/css'>
-->
  	 <link rel="stylesheet" href="../bootstrap.min.css">	 
  	 <script src="../jquery.min.js"></script>
  	 <script src="../bootstrap.min.js"></script>
  		<script>
  			$(window).load(function(){
  				
  			});
  		</script>
</head>
<body>
<div id="container-fluid">
 /*  */
</div>
</body>
</html>