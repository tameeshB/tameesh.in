<?PHP
$servername = "sbg1.freeho.st";
$username = "tameeshi_gen";
$password = "Pswd4db.";
$dbname = "tameeshi_auth";
?>