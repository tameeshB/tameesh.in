<?php
	//add well to display only the title and date on the bottom, possibly a well or even better a blockquote or a definition list
	
?>