<?PHP 
date_default_timezone_set('Asia/Calcutta');
echo date('d_F_Y_h_i_s_A');
?>